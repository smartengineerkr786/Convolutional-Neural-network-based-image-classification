function [th] = cnntest(net, x, y)
    net = cnnff(net, x);
    h=numel(net);
    [~, th] = max(y);
end
