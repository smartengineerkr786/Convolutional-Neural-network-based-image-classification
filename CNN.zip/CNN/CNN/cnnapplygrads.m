function cnn_net = cnnapplygrads(cnn_net, opts)
    for l = 2 : numel(cnn_net.step)
        if strcmp(cnn_net.step{l}.type, 'c')
            for j = 1 : numel(cnn_net.step{l}.a)
                for ii = 1 : numel(cnn_net.step{l - 1}.a)
                    cnn_net.step{l}.k{ii}{j} = cnn_net.step{l}.k{ii}{j} - opts.alpha * cnn_net.step{l}.dk{ii}{j};
                end
                cnn_net.step{l}.b{j} = cnn_net.step{l}.b{j} - opts.alpha * cnn_net.step{l}.db{j};
            end
        end
    end

    cnn_net.ffW = cnn_net.ffW - opts.alpha * cnn_net.dffW;
    cnn_net.ffb = cnn_net.ffb - opts.alpha * cnn_net.dffb;
end
