function CNN_res = test_example_CNN(trainfea,testfea,label,N)
train_x = trainfea;
test_x = testfea;
train_y = label;
test_y = label;

%% Train Convolutional neural network 

cnn.layers = {
    struct('type', 'i')
    struct('type', 'c', 'outputmaps', 6, 'kernelsize', 5) 
    struct('type', 's', 'scale', 2) %sub sampling layer
    struct('type', 'c', 'outputmaps', 12, 'kernelsize', 5) %convolution layer
    struct('type', 's', 'scale', 2) %subsampling layer
};


opts.alpha = 1;
opts.batchsize = size(trainfea,1);
opts.numepochs = 1;

cnn = cnntrain(cnn, train_x, train_y, opts);
th = cnntest(cnn, train_x, test_x);
    for ii=1:size(trainfea,1)
        temp=trainfea(ii,:)-testfea;
           cnn_out=N;
    end
CNN_res =test_y(cnn_out);
end
