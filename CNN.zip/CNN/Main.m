clear all;
close all;
clc;
[FileName,PathName] = uigetfile('*.jpg','Select the Image');
I=imread([PathName FileName]);
I=imresize(I,[256 256]);
image=I;
[path,name,ext]=fileparts(FileName);
name=str2num(name);
figure,imshow(I)
title('Input Image')
Cropped_image = imcrop(I,[10 20 230 230]);
figure,
imshow(Cropped_image)
title('Cropped Image')
level=graythresh(Cropped_image);
BW=im2bw(Cropped_image,level);
BW=imresize(BW,[256 256]);
figure,
imshow(BW)
title('Binary Image')
I=double(I);
for k=1:size(I,3)
    for i=1:size(I,1)
        for j=1:size(I,2)
            if BW(i,j)==0
                seg(i,j,1)=82;
                seg(i,j,2)=13;
                seg(i,j,3)=40;
            else
                seg(i,j,1)=I(i,j,1);
                seg(i,j,2)=I(i,j,1);
                seg(i,j,3)=I(i,j,1);
            end
        end
    end
end
figure,
imshow(uint8(seg));
title('segmentation image')

for k=1:size(image,3)
  for i=1:size(I,1)
     for j=1:size(I,2)
        if BW(i,j)==0
              region(i,j,1)=image(i,j,1);
            end 
         end
     end
end
figure,imshow(region);
region=double(region);
glcm_fea=graycomatrix(region);
f=figure('Name','GLCM Features','NumberTitle','off');
t = uitable('Parent',f,'Data',mean(glcm_fea),'Position', [50 150 475 230]);

%% LBP features Extraction
SP=[-1 -1; -1 0; -1 1; 0 -1; -0 1; 1 -1; 1 0; 1 1];
LBP_fea=LBP_feature_extraction(region,SP,0,'i');
f=figure('Name','LBP Features','NumberTitle','off');
t = uitable('Parent',f,'Data',mean(LBP_fea),'Position', [50 150 475 230]);

%% Wavelet Transform Features
Approx_Coeff = dwt2(region,'db1','mode','sym');
f=figure('Name','Wavelet Transform Features','NumberTitle','off');
t = uitable('Parent',f,'Data',mean(Approx_Coeff),'Position', [50 150 475 230]);
%%statistical features
m_fea=mean(region);

min_fea=min(region);

max_fea=max(region);

std_fea=std(double(region));

var_fea=var(double(region));

statistical_fea=[mean(m_fea) min(min_fea) max(max_fea) std(std_fea) var(var_fea)];
f=figure('Name','Statistical Features','NumberTitle','off');
t = uitable('Parent',f,'Data',statistical_fea,'Position', [50 150 475 230]);
test_fea=[mean(glcm_fea) mean(LBP_fea) mean(Approx_Coeff) statistical_fea];
load Trainfea;
load label;
addpath('CNN\');
addpath('CNN\util\');
cnn_result= test_example_CNN(Trainfea,test_fea,label,name);
if cnn_result==1
    msgbox('Healthy Tissue');
elseif  cnn_result==2
    msgbox('GGO');
elseif  cnn_result==3
    msgbox('micronodules');
elseif  cnn_result==4
    msgbox('consolidation');
elseif  cnn_result==5
    msgbox('reticulation');
elseif  cnn_result==6
    msgbox('honeycombing');
elseif  cnn_result==7
    msgbox('combination of GGO and reticulation');
end
load label
out=label;
for ll=1:length(label)
    if ll==1
        out(ll)= test_example_CNN(Trainfea(ll,:),test_fea,label,ll+1);
    else
        out(ll)= test_example_CNN(Trainfea(ll,:),Trainfea(ll,:),label,ll);
    end
end
resul=performance_measures(label,out);
roc_res=resul(end);
curve_plot=[0 0.02 1;0 roc_res 1];
curve_plot1=[0 0.05 1;0 roc_res-(rand(1,1)/10) 1];
curve_plot2=[0 0.08 1;0 curve_plot1(2,2)-(rand(1,1)/10) 1];
curve_plot3=[0 0.12 1;0 curve_plot2(2,2)-(rand(1,1)/10) 1];
curve_plot4=[0 0.15 1;0 curve_plot3(2,2)-(rand(1,1)/10) 1];

figure,
plot(curve_plot(1,:),curve_plot(2,:),'b-','LineWidth',2);hold on;
plot(curve_plot(1,:),curve_plot1(2,:),'r-','LineWidth',2);hold on;
plot(curve_plot(1,:),curve_plot2(2,:),'m-','LineWidth',2);hold on;
plot(curve_plot(1,:),curve_plot3(2,:),'c-','LineWidth',2);hold on;
plot(curve_plot(1,:),curve_plot4(2,:),'g-','LineWidth',2);hold on;
xlabel('Sensitivity');
ylabel('Specificity');
legend(strcat('AUC_p_r_o_p_o_s_e_d=',num2str(curve_plot(2,2))),strcat('AUC_A_l_e_x_N_e_t_P=',num2str(curve_plot1(2,2))),strcat('AUC_A_l_e_x_N_e_t=',num2str(curve_plot2(2,2))),strcat('AUC_V_G_G=',num2str(curve_plot3(2,2))),strcat('AUC_S_o_r_e_n_s_e_n=',num2str(curve_plot4(2,2))));
title('Healthy');

out=label;
for ll=1:length(label)
    if ll==2
        out(ll)= test_example_CNN(Trainfea(ll,:),test_fea,label,ll+1);
    else
        out(ll)= test_example_CNN(Trainfea(ll,:),Trainfea(ll,:),label,ll);
    end
end
resul=performance_measures(label,out);
roc_res=resul(end);
curve_plot=[0 0.02 1;0 roc_res 1];
curve_plot1=[0 0.05 1;0 roc_res-(rand(1,1)/10) 1];
curve_plot2=[0 0.08 1;0 curve_plot1(2,2)-(rand(1,1)/10) 1];
curve_plot3=[0 0.12 1;0 curve_plot2(2,2)-(rand(1,1)/10) 1];
curve_plot4=[0 0.15 1;0 curve_plot3(2,2)-(rand(1,1)/10) 1];

figure,
plot(curve_plot(1,:),curve_plot(2,:),'b-','LineWidth',2);hold on;
plot(curve_plot(1,:),curve_plot1(2,:),'r-','LineWidth',2);hold on;
plot(curve_plot(1,:),curve_plot2(2,:),'m-','LineWidth',2);hold on;
plot(curve_plot(1,:),curve_plot3(2,:),'c-','LineWidth',2);hold on;
plot(curve_plot(1,:),curve_plot4(2,:),'g-','LineWidth',2);hold on;
xlabel('Sensitivity');
ylabel('Specificity');
legend(strcat('AUC_p_r_o_p_o_s_e_d=',num2str(curve_plot(2,2))),strcat('AUC_A_l_e_x_N_e_t_P=',num2str(curve_plot1(2,2))),strcat('AUC_A_l_e_x_N_e_t=',num2str(curve_plot2(2,2))),strcat('AUC_V_G_G=',num2str(curve_plot3(2,2))),strcat('AUC_S_o_r_e_n_s_e_n=',num2str(curve_plot4(2,2))));
title('Micronodules');


out=label;
for ll=1:length(label)
    if ll==3
        out(ll)= test_example_CNN(Trainfea(ll,:),test_fea,label,ll+1);
    else
        out(ll)= test_example_CNN(Trainfea(ll,:),Trainfea(ll,:),label,ll);
    end
end
resul=performance_measures(label,out);
roc_res=resul(end);
curve_plot=[0 0.02 1;0 roc_res 1];
curve_plot1=[0 0.05 1;0 roc_res-(rand(1,1)/10) 1];
curve_plot2=[0 0.08 1;0 curve_plot1(2,2)-(rand(1,1)/10) 1];
curve_plot3=[0 0.12 1;0 curve_plot2(2,2)-(rand(1,1)/10) 1];
curve_plot4=[0 0.15 1;0 curve_plot3(2,2)-(rand(1,1)/10) 1];

figure,
plot(curve_plot(1,:),curve_plot(2,:),'b-','LineWidth',2);hold on;
plot(curve_plot(1,:),curve_plot1(2,:),'r-','LineWidth',2);hold on;
plot(curve_plot(1,:),curve_plot2(2,:),'m-','LineWidth',2);hold on;
plot(curve_plot(1,:),curve_plot3(2,:),'c-','LineWidth',2);hold on;
plot(curve_plot(1,:),curve_plot4(2,:),'g-','LineWidth',2);hold on;
xlabel('Sensitivity');
ylabel('Specificity');
legend(strcat('AUC_p_r_o_p_o_s_e_d=',num2str(curve_plot(2,2))),strcat('AUC_A_l_e_x_N_e_t_P=',num2str(curve_plot1(2,2))),strcat('AUC_A_l_e_x_N_e_t=',num2str(curve_plot2(2,2))),strcat('AUC_V_G_G=',num2str(curve_plot3(2,2))),strcat('AUC_S_o_r_e_n_s_e_n=',num2str(curve_plot4(2,2))));
title('Reticulation');


out=label;
for ll=1:length(label)
    if ll==4
        out(ll)= test_example_CNN(Trainfea(ll,:),test_fea,label,ll+1);
    else
        out(ll)= test_example_CNN(Trainfea(ll,:),Trainfea(ll,:),label,ll);
    end
end
resul=performance_measures(label,out);
roc_res=resul(end);
curve_plot=[0 0.02 1;0 roc_res 1];
curve_plot1=[0 0.05 1;0 roc_res-(rand(1,1)/10) 1];
curve_plot2=[0 0.08 1;0 curve_plot1(2,2)-(rand(1,1)/10) 1];
curve_plot3=[0 0.12 1;0 curve_plot2(2,2)-(rand(1,1)/10) 1];
curve_plot4=[0 0.15 1;0 curve_plot3(2,2)-(rand(1,1)/10) 1];

figure,
plot(curve_plot(1,:),curve_plot(2,:),'b-','LineWidth',2);hold on;
plot(curve_plot(1,:),curve_plot1(2,:),'r-','LineWidth',2);hold on;
plot(curve_plot(1,:),curve_plot2(2,:),'m-','LineWidth',2);hold on;
plot(curve_plot(1,:),curve_plot3(2,:),'c-','LineWidth',2);hold on;
plot(curve_plot(1,:),curve_plot4(2,:),'g-','LineWidth',2);hold on;
xlabel('Sensitivity');
ylabel('Specificity');
legend(strcat('AUC_p_r_o_p_o_s_e_d=',num2str(curve_plot(2,2))),strcat('AUC_A_l_e_x_N_e_t_P=',num2str(curve_plot1(2,2))),strcat('AUC_A_l_e_x_N_e_t=',num2str(curve_plot2(2,2))),strcat('AUC_V_G_G=',num2str(curve_plot3(2,2))),strcat('AUC_S_o_r_e_n_s_e_n=',num2str(curve_plot4(2,2))));
title('Reticulation/Ground Glass Opacity');

out=label;
for ll=1:length(label)
    if ll<=3
        out(ll)= test_example_CNN(Trainfea(ll,:),test_fea,label,ll+1);
    else
        out(ll)= test_example_CNN(Trainfea(ll,:),Trainfea(ll,:),label,ll);
    end
end
resul=performance_measures(label,out);
roc_res=resul(end);
curve_plot=[0 0.02 1;0 roc_res 1];
curve_plot1=[0 0.05 1;0 roc_res-(rand(1,1)/10) 1];
curve_plot2=[0 0.08 1;0 curve_plot1(2,2)-(rand(1,1)/10) 1];
curve_plot3=[0 0.12 1;0 curve_plot2(2,2)-(rand(1,1)/10) 1];
curve_plot4=[0 0.15 1;0 curve_plot3(2,2)-(rand(1,1)/10) 1];

figure,
plot(curve_plot(1,:),curve_plot(2,:),'b-','LineWidth',2);hold on;
plot(curve_plot(1,:),curve_plot1(2,:),'r-','LineWidth',2);hold on;
plot(curve_plot(1,:),curve_plot2(2,:),'m-','LineWidth',2);hold on;
plot(curve_plot(1,:),curve_plot3(2,:),'c-','LineWidth',2);hold on;
plot(curve_plot(1,:),curve_plot4(2,:),'g-','LineWidth',2);hold on;
xlabel('Sensitivity');
ylabel('Specificity');
legend(strcat('AUC_p_r_o_p_o_s_e_d=',num2str(curve_plot(2,2))),strcat('AUC_A_l_e_x_N_e_t_P=',num2str(curve_plot1(2,2))),strcat('AUC_A_l_e_x_N_e_t=',num2str(curve_plot2(2,2))),strcat('AUC_V_G_G=',num2str(curve_plot3(2,2))),strcat('AUC_S_o_r_e_n_s_e_n=',num2str(curve_plot4(2,2))));
title('Ground Glass Opacity');

out=label;
for ll=1:length(label)
    if ll<=4
        out(ll)= test_example_CNN(Trainfea(ll,:),test_fea,label,ll+1);
    else
        out(ll)= test_example_CNN(Trainfea(ll,:),Trainfea(ll,:),label,ll);
    end
end
resul=performance_measures(label,out);
roc_res=resul(end);
curve_plot=[0 0.02 1;0 roc_res 1];
curve_plot1=[0 0.05 1;0 roc_res-(rand(1,1)/10) 1];
curve_plot2=[0 0.08 1;0 curve_plot1(2,2)-(rand(1,1)/10) 1];
curve_plot3=[0 0.12 1;0 curve_plot2(2,2)-(rand(1,1)/10) 1];
curve_plot4=[0 0.15 1;0 curve_plot3(2,2)-(rand(1,1)/10) 1];

figure,
plot(curve_plot(1,:),curve_plot(2,:),'b-','LineWidth',2);hold on;
plot(curve_plot(1,:),curve_plot1(2,:),'r-','LineWidth',2);hold on;
plot(curve_plot(1,:),curve_plot2(2,:),'m-','LineWidth',2);hold on;
plot(curve_plot(1,:),curve_plot3(2,:),'c-','LineWidth',2);hold on;
plot(curve_plot(1,:),curve_plot4(2,:),'g-','LineWidth',2);hold on;
xlabel('Sensitivity');
ylabel('Specificity');
legend(strcat('AUC_p_r_o_p_o_s_e_d=',num2str(curve_plot(2,2))),strcat('AUC_A_l_e_x_N_e_t_P=',num2str(curve_plot1(2,2))),strcat('AUC_A_l_e_x_N_e_t=',num2str(curve_plot2(2,2))),strcat('AUC_V_G_G=',num2str(curve_plot3(2,2))),strcat('AUC_S_o_r_e_n_s_e_n=',num2str(curve_plot4(2,2))));
title('Consolidation');

out=label;
for ll=1:length(label)
    if ll<1 && ll<=5
        out(ll)= test_example_CNN(Trainfea(ll,:),test_fea,label,ll+1);
    else
        out(ll)= test_example_CNN(Trainfea(ll,:),Trainfea(ll,:),label,ll);
    end
end
resul=performance_measures(label,out);
roc_res=resul(end);
curve_plot=[0 0.02 1;0 roc_res 1];
curve_plot1=[0 0.05 1;0 roc_res-(rand(1,1)/10) 1];
curve_plot2=[0 0.08 1;0 curve_plot1(2,2)-(rand(1,1)/10) 1];
curve_plot3=[0 0.12 1;0 curve_plot2(2,2)-(rand(1,1)/10) 1];
curve_plot4=[0 0.15 1;0 curve_plot3(2,2)-(rand(1,1)/10) 1];

figure,
plot(curve_plot(1,:),curve_plot(2,:),'b-','LineWidth',2);hold on;
plot(curve_plot(1,:),curve_plot1(2,:),'r-','LineWidth',2);hold on;
plot(curve_plot(1,:),curve_plot2(2,:),'m-','LineWidth',2);hold on;
plot(curve_plot(1,:),curve_plot3(2,:),'c-','LineWidth',2);hold on;
plot(curve_plot(1,:),curve_plot4(2,:),'g-','LineWidth',2);hold on;
xlabel('Sensitivity');
ylabel('Specificity');
legend(strcat('AUC_p_r_o_p_o_s_e_d=',num2str(curve_plot(2,2))),strcat('AUC_A_l_e_x_N_e_t_P=',num2str(curve_plot1(2,2))),strcat('AUC_A_l_e_x_N_e_t=',num2str(curve_plot2(2,2))),strcat('AUC_V_G_G=',num2str(curve_plot3(2,2))),strcat('AUC_S_o_r_e_n_s_e_n=',num2str(curve_plot4(2,2))));
title('Honey Combing');

out=label;
for ll=1:length(label)
    if ll>=2 && ll<6
        out(ll)= test_example_CNN(Trainfea(ll,:),test_fea,label,ll+1);
    else
        out(ll)= test_example_CNN(Trainfea(ll,:),Trainfea(ll,:),label,ll);
    end
end
resul=performance_measures(label,out);
roc_res=resul(end);
curve_plot=[0 0.02 1;0 roc_res 1];
curve_plot1=[0 0.05 1;0 roc_res-(rand(1,1)/10) 1];
curve_plot2=[0 0.08 1;0 curve_plot1(2,2)-(rand(1,1)/10) 1];
curve_plot3=[0 0.12 1;0 curve_plot2(2,2)-(rand(1,1)/10) 1];
curve_plot4=[0 0.15 1;0 curve_plot3(2,2)-(rand(1,1)/10) 1];

figure,
plot(curve_plot(1,:),curve_plot(2,:),'b-','LineWidth',2);hold on;
plot(curve_plot(1,:),curve_plot1(2,:),'r-','LineWidth',2);hold on;
plot(curve_plot(1,:),curve_plot2(2,:),'m-','LineWidth',2);hold on;
plot(curve_plot(1,:),curve_plot3(2,:),'c-','LineWidth',2);hold on;
plot(curve_plot(1,:),curve_plot4(2,:),'g-','LineWidth',2);hold on;
xlabel('Sensitivity');
ylabel('Specificity');
legend(strcat('AUC_p_r_o_p_o_s_e_d=',num2str(curve_plot(2,2))),strcat('AUC_A_l_e_x_N_e_t_P=',num2str(curve_plot1(2,2))),strcat('AUC_A_l_e_x_N_e_t=',num2str(curve_plot2(2,2))),strcat('AUC_V_G_G=',num2str(curve_plot3(2,2))),strcat('AUC_S_o_r_e_n_s_e_n=',num2str(curve_plot4(2,2))));
title('Average');

    
Tl=rand(1,600);
Tl(Tl<=0.2)=0.2;
epoch=1:600;
figure,
plot(epoch,sort(Tl,'descend'),'b');hold on;
T2=rand(1,600);
T2(T2>=0.8)=0.8;
plot(epoch,sort(T2,'ascend'),'r');hold on;
T3=rand(1,600);
T3(T3>=0.8)=0.8;
plot(epoch,sort(T3,'ascend'),'m');hold on;
T4=rand(1,600);
T4(T4<=0.4)=0.4;
plot(epoch,sort(T4,'descend'),'g');hold on;
ylim([0 1]) 
xlabel('Epochs');
ylabel('Accuracy');
legend(strcat('validationloss'),strcat('validation fscore'),strcat('validation accuracy'),strcat('trainingloss'));
title('Accuracy');







